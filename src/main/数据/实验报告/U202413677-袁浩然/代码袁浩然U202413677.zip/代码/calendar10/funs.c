#include <stdio.h>
#include <stdlib.h>

#include "date.h"
#include "funs.h"

extern int Month_NORMAL_YEAR [12] ;

extern int Month_LEAP_YEAR [12] ;


void printoneWeek( Day prepareday ){
	Day remain = prepareday;
	int i = 0;
	int index = 1;
		printf(" #W:%10s%10s%10s%10s%10s%10s%10s\n", "Mon.", "Tues.", "Wed.", "Thur.", "Fri.", "Sat.", "Sun.");
		if(remain.dayseq + 7 - remain.weekDay > isLeapYear(prepareday.year) + 365){
			prepareday.weekseq = 1;
		}
		printf("[%02d]",prepareday.weekseq);
		if(i == 0)
		{
			int j;
			for( j = 1; j < remain.weekDay ; j++){
				printf("%10s"," ");
			}
		}
		int k;
		for( k = 0; k <= printDayRange;k ++){
			if(k  == 0){
				printf("  %02d.%02d.%02d",prepareday.year-100*(prepareday.year/100), prepareday.month,prepareday.day);
				prepareday.day ++;
				prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

				continue;
			}
			if(k + remain.weekDay > 7 *index){
				getWeekSeqOfYear( prepareday.year, prepareday.month,getThisSunday( prepareday.year,prepareday.dayseq ));
				if(prepareday.dayseq +7 > isLeapYear(prepareday.year) + 365){
					prepareday.weekseq = 1;
				}
				printf("\n");
				printf("[%02d]",prepareday.weekseq);
				index ++;
			}
			if(k == printDayRange){
				if(remain.dayseq + k > isLeapYear(prepareday.year) + 365){
					prepareday.month = 1;
					prepareday.day = 1;
					prepareday.year ++;
					prepareday.dayseq = 1;
					prepareday.weekseq = 0;
					printf(" %02d.%02d.%02d*",prepareday.year-100*(prepareday.year/100) , prepareday.month,prepareday.day);
					prepareday.day ++;
					prepareday.dayseq ++;
					remain.dayseq = 2;
					prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

					continue;
				}else if(prepareday.month == 2 &&  isLeapYear(prepareday.year) == 1 && prepareday.day == 29){

					printf("     %02d.%02d*",prepareday.month,prepareday.day);
					prepareday.month++;
					prepareday.day = 1;
					prepareday.dayseq ++;
					prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

					continue;
				}else if(prepareday.day >  Month_NORMAL_YEAR[prepareday.month - 1]){
					prepareday.day = 1;
					prepareday.month ++;
					printf("    %02d.%02d*",prepareday.month,prepareday.day);
					prepareday.day++;
					prepareday.dayseq ++;
					prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

					continue;
				}else{
					printf("     %02d,%02d*",prepareday.month,prepareday.day);
					prepareday.day ++;
					prepareday.dayseq ++;
					prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

					continue;
				}

		}
			if(remain.dayseq + k > isLeapYear(prepareday.year) + 365){
				prepareday.month = 1;
				prepareday.day = 1;
				prepareday.year ++;
				prepareday.dayseq = 1;
				prepareday.weekseq = 0;
				printf("  %02d.%02d.%02d",prepareday.year-100*(prepareday.year/100) , prepareday.month,prepareday.day);
				prepareday.day++;
				prepareday.dayseq ++;
				prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );
				remain.dayseq = 2;
				continue;
			}else if(prepareday.month == 2 &&  isLeapYear(prepareday.year) == 1 && prepareday.day == 29){

				printf("        %02d",prepareday.day);
				prepareday.month++;
				prepareday.day = 1;
				prepareday.dayseq ++;
				prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

				continue;
			}else if(prepareday.day >  Month_NORMAL_YEAR[prepareday.month - 1]){
				prepareday.day = 1;
				prepareday.month ++;
				printf("     %02d.%02d",prepareday.month,prepareday.day);
				prepareday.day++;
				prepareday.dayseq ++;
				prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );

				continue;
			}else{

				printf("        %02d",prepareday.day);
				prepareday.dayseq += 1;
				prepareday.day ++;
				prepareday.weekseq = getWeekSeqOfYear( prepareday.year, prepareday.month, prepareday.day );
				if(prepareday.dayseq > isLeapYear(remain.year) + 365){
					prepareday.weekseq = 1;
				}
				continue;
			}

		}
}

//void printOneDay( Day prepareday ,int j){
//	if(prepareday.weekDay + index   > 7){
//		break;
//	}
//	if(prepareday.weekDay > j+1){
//		printf("%10s"," ");
//	}else if(prepareday.weekDay <= j+1){
//
//	}
//}



//void printOneDay( int year, int daySeqOfYear , int formatType )
//{
//    int day = getDay( year, daySeqOfYear);
//    int month = getMonth( year, daySeqOfYear);
//    int week = getDaySeqOfWeek( year, daySeqOfYear);
//
//    if( formatType == 1 )
//    {
//        printf("%2s%02d.%02d.%02d"," ", year % 100 , month, day);
//    }
//
//    else if( day == 1)
//    {
//        if( month == 1)
//        {
//            if( week == 6|| week == 0)
//            {
//                printf("%1s%02d.%02d.%02d!"," ", year % 100 , month, day);
//            }
//
//            else
//            {
//                printf("%2s%02d.%02d.%02d"," ", year % 100 , month, day);
//            }
//        }
//
//        else if( week == 6|| week == 0)
//        {
//            printf("%4s%02d.%02d!"," ", month, day);
//        }
//
//        else
//        {
//            printf("%5s%02d.%02d"," ", month, day);
//        }
//    }
//
//    else
//    {
//        if( week == 6|| week == 0)
//        {
//            printf("%9d!", day);
//        }
//
//        else
//        {
//            printf("%10d", day);
//        }
//    }
//}
//
//void printoneWeek(int year, int weekSeqOfYear, int weekSeqShow )
//{
//
//    printf("[%02d]", weekSeqShow) ;
//
//    int sStartSeqOfYear = 7 * ( weekSeqOfYear - 1 ) - getDaySeqOnJan1( year ) + 2 ;
//    int sEndSeqOfYear = sStartSeqOfYear + 6 ;
//    int currentyear = 365 + isLeapYear( year ) ;
//    int daySeqOfYear = sStartSeqOfYear ;
//
//    if( weekSeqShow == 1)
//    {
//        printOneDay( year, daySeqOfYear , DATE_INFO_FULL ) ;
//
//        daySeqOfYear ++ ;
//    }
//
//
//    for( ; daySeqOfYear <= sEndSeqOfYear ; daySeqOfYear ++ )
//    {
//        if( daySeqOfYear <= currentyear )
//        {
//            printOneDay( year, daySeqOfYear , DATE_INFO_BRIEF ) ;
//        }
//
//        else
//        {
//            printOneDay( year + 1, daySeqOfYear - currentyear , DATE_INFO_BRIEF ) ;
//        }
//
//    }
//
//    printf("\n") ;
//}



