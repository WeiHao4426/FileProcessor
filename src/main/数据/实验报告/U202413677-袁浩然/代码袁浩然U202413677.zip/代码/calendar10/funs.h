#ifndef FUNS_H_INCLUDED
#define FUNS_H_INCLUDED

//void printOneDay( int year, int daySeqOfYear , int formatType );
//void printoneWeek(int year, int weekSeqOfYear, int weekSeqShow );
//void printOneDay( Day day);
void printoneWeek( Day day);

#endif // FUNS_H_INCLUDED

