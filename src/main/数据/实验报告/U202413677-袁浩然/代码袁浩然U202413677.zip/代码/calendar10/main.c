#include <stdio.h>
#include <stdlib.h>
#include "date.h"
#include "funs.h"



const int Years[5] = {2024,2025,2026,2027,2028,};

const int Month_NORMAL_YEAR [12] =
{31,28,31,30,31,30,31,31,30,31,30,31};

const int Month_LEAP_YEAR [12] =
{31,29,31,30,31,30,31,31,30,31,30,31};



int main()
{

	int inputMonth,inputDay;
    int i = 0;
    Day birthDay = {0};
    Day prepareDay = {0};
    Day printDay = {0};
	Day prepareday = {0};
//	ggb:
    printf("please input month: \n");
    scanf("%d", &inputMonth) ;
    printf("please input day: \n");
    scanf("%d", &inputDay) ;
	int j = 0;



	for (i = 0; i < YEAR_NUM; i++)
	{
		    birthDay = setDay (Years[i],inputMonth,inputDay);
    prepareDay = getDayBefore (birthDay, printDayRange);
    prepareday = prepareDay;
	    printf("\%s%s%d\n", " ", "Birthday in Year ", Years[i]);
	    if (isDay(Years[i], inputMonth, inputDay)!= 1)
	    {
	        printf(" Not found.\n");
	        continue;
	    }

	    printDay = setDay (Years[i],inputMonth,inputDay + i);
	  //  printf("#W:%10s%10s%10s%10s%10s%10s%10s\n", "Mon.", "Tues.", "Wed.", "Thur.", "Fri.", "Sat.", "Sun.");
		printoneWeek(prepareday);


	    printf("\n\n");
	}
//	goto ggb;
    return 0 ;
}

