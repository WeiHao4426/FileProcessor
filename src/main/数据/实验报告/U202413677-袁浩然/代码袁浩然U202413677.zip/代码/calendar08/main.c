#include <stdio.h>
#include <stdlib.h>
#include "date.h"
#include "funs.h"

const int Month_NORMAL_YEAR [12] =
{31,28,31,30,31,30,31,31,30,31,30,31};

const int Month_LEAP_YEAR [12] =
{31,29,31,30,31,30,31,31,30,31,30,31};

int main()
{
    int year ,Years[ YEAR_NUM ];

    printf("Spring Calendar Comparision in %d years, please input the first year (%d-%d): \n",
           YEAR_NUM, YEAR_MIN, YEAR_MAX - YEAR_NUM ) ;

    scanf("%d", &year) ;

    if( year < YEAR_MIN || year + YEAR_NUM > YEAR_MAX )
    {
        printf("\nInvalid input!\n") ;
        return 0 ;
    }

    setYearArray( Years, YEAR_NUM, year );

    int i;
    int startDays[ YEAR_NUM ] = {0} ;

    for( i = 0 ; i< YEAR_NUM ; i ++ )
    {
        printf("\n%s%s%d\n"," ","First week in spring calendar of Year ", Years[i]) ;
        printf("#W:%10s%10s%10s%10s%10s%10s%10s\n"
           ,"Mon.","Tues.","Wend.","Thur.","Fri.","Sat.","Sun.") ;
        printoneWeek( Years[ i ], getWeekSeqOfYear( Years[ i ], 9, 4 ), 1) ;
        startDays[ i ] = getThisMonday( Years[ i ], getWeekSeqOfYear( Years[ i ], 9, 4 )) ;
    }

    int min = 0 ;

    for( i = 1 ; i < YEAR_NUM ; i ++)
    {
        min = ( startDays[ i ] < startDays[ min ]) ? i : min ;
    }

    printf("\n%s%s%d\n"," " ,"Earliest Spring Semester is in Year " , Years[min] );

    return 0 ;
}
