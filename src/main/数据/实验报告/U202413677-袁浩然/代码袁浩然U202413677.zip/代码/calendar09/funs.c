#include <stdio.h>
#include <stdlib.h>

#include "date.h"
#include "funs.h"

void printOneDay( int year, int daySeqOfYear , int formatType )
{
    int day = getDay( year, daySeqOfYear);
    int month = getMonth( year, daySeqOfYear);
    int week = getDaySeqOfWeek( year, daySeqOfYear);

    if( formatType == 1 )
    {
        printf("%2s%02d.%02d.%02d"," ", year % 100 , month, day);
    }

    else if( day == 1)
    {
        if( month == 1)
        {
            if( week == 6|| week == 0)
            {
                printf("%1s%02d.%02d.%02d!"," ", year % 100 , month, day);
            }

            else
            {
                printf("%2s%02d.%02d.%02d"," ", year % 100 , month, day);
            }
        }

        else if( week == 6|| week == 0)
        {
            printf("%4s%02d.%02d!"," ", month, day);
        }

        else
        {
            printf("%5s%02d.%02d"," ", month, day);
        }
    }

    else
    {
        if( week == 6|| week == 0)
        {
            printf("%9d!", day);
        }

        else
        {
            printf("%10d", day);
        }
    }
}

void printoneWeek(int year, int weekSeqOfYear, int weekSeqShow )
{


    printf("[%02d]", weekSeqShow) ;

    int sStartSeqOfYear = 7 * ( weekSeqOfYear - 1 ) - getDaySeqOnJan1( year ) + 2 ;
    int sEndSeqOfYear = sStartSeqOfYear + 6 ;
    int currentyear = 365 + isLeapYear( year ) ;
    int daySeqOfYear = sStartSeqOfYear ;

    if( weekSeqShow == 1)
    {
        printOneDay( year, daySeqOfYear , DATE_INFO_FULL ) ;

        daySeqOfYear ++ ;
    }


    for( ; daySeqOfYear <= sEndSeqOfYear ; daySeqOfYear ++ )
    {
        if( daySeqOfYear <= currentyear )
        {
            printOneDay( year, daySeqOfYear , DATE_INFO_BRIEF ) ;
        }

        else
        {
            printOneDay( year + 1, daySeqOfYear - currentyear , DATE_INFO_BRIEF ) ;
        }

    }

    printf("\n") ;
}

