#ifndef DATE_H_INCLUDED
#define DATE_H_INCLUDED

#define YEAR_MIN 2019
#define YEAR_MAX 2026
#define YEAR_NUM 8
#define DATE_INFO_BRIEF 0
#define DATE_INFO_FULL 1

int isLeapYear( int year );
int getDaySeqOnJan1( int year );

int getDaySeq( int year, int month, int day );
int getWeekSeqOfYear( int year, int month, int day );

int getMonth( int year, int daySeqOfYear );
int getDay( int year, int daySeqOfYear );
int getDaySeqOfWeek( int year,int daySeqOfYear );

int getNextMonday( int year, int daySeqOfYear );
int getThisMonday ( int year, int day );
int getThisSunday( int year, int daySeqOfYear );

void setYearArray( int Years[], int yearnum, int year );

#endif // DATE_H_INCLUDED
