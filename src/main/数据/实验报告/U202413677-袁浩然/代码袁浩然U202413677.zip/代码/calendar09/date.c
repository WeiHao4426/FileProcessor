#include <stdio.h>
#include <stdlib.h>

#include "date.h"
#include "funs.h"

#define MONTH_NUM 12

int getDay( int year, int daySeqOfYear )
{
    extern int  Month_LEAP_YEAR[12];
    extern int  Month_NORMAL_YEAR[12];

    int i = 0 ;
    int ret = daySeqOfYear ;

    if( isLeapYear( year ) == 1 )
    {
        while( ret > Month_LEAP_YEAR[ i ] )
        {
            ret -= Month_LEAP_YEAR[ i ] ;

            i ++ ;
        }
    }

    else
    {
        while( ret > Month_NORMAL_YEAR[ i ] )
        {
            ret -= Month_NORMAL_YEAR[ i ] ;

            i ++ ;
        }
    }

    return  ret ;
}

int getDaySeq( int year, int month, int day )
{
    switch( month )
    {
        case 12:
            day += 30 ;

        case 11:
            day += 31 ;

        case 10:
            day += 30 ;

        case 9:
            day += 31 ;

        case 8:
            day += 31 ;

        case 7:
            day += 30 ;

        case 6:
            day += 31 ;

        case 5:
            day += 30 ;

        case 4:
            day += 31 ;

        case 3:
            day += 28 + isLeapYear( year ) ;

        case 2:
            day += 31 ;

        break ;
    }

    return day ;
}

int getDaySeqOfWeek( int year, int daySeqOfYear )
{

    daySeqOfYear += getDaySeqOnJan1( year ) - 1 ;

    daySeqOfYear = daySeqOfYear % 7 ;

    return daySeqOfYear ;
}

int getDaySeqOnJan1( int year )
{
    int result ;

    result = ( year - 1 +( year - 1) / 4 - ( year - 1)/ 100 +( year - 1)/ 400) % 7 + 1 ;

    return result ;
}

int getMonth( int year, int dayseq )
{
    extern int  Month_LEAP_YEAR[12];
    extern int  Month_NORMAL_YEAR[12];

    int temp = 1 ;

    if( isLeapYear( year ) == 1 )
    {
        while( dayseq > Month_LEAP_YEAR[ temp - 1 ] )
        {
            dayseq -= Month_LEAP_YEAR[ temp - 1 ] ;

            temp ++ ;
        }
    }

    else
    {
        while( dayseq > Month_NORMAL_YEAR[ temp - 1 ] )
        {
            dayseq -= Month_NORMAL_YEAR[ temp - 1 ] ;

            temp ++ ;
        }
    }
    return temp ;
}


int getNextMonday( int year, int day )
{
    if( ( day + getDaySeqOnJan1( year ) - 1 ) % 7 != 1)
    {
        if(( day + getDaySeqOnJan1( year ) - 1 ) % 7 == 0)
        {
            day ++ ;
        }

        else
        {
            day += (7 -( day + getDaySeqOnJan1( year ) - 1 ) % 7) + 1 ;
        }
    }

    return day ;
}

int getThisMonday ( int year, int day )
{
    if( ( day + getDaySeqOnJan1( year ) - 1 ) % 7 != 1)
    {
        if(( day + getDaySeqOnJan1( year ) - 1 ) % 7 == 0)
        {
            day -= 6 ;
        }

        else
        {
            day -= ( day + getDaySeqOnJan1( year ) - 1 ) % 7 - 1 ;
        }
    }

    /* day = getNextMonday ( year, day) - 7 ; */

    return day ;
}

int getThisSunday( int year, int day )
{
    if( ( day + getDaySeqOnJan1( year ) - 1 ) % 7 != 0)
    {
        day += 7 -(day + getDaySeqOnJan1( year ) - 1 ) % 7 ;
    }

    return day ;
}

int isLeapYear( int year )
{
    if( ( year % 4 == 0 && year % 100 != 0) || year % 400 == 0 )
    {
        return 1 ;
    }

    return 0 ;
}

int getWeekSeqOfYear( int year, int month, int day )
{
    int week ;

    int daySeqOfYear = getDaySeq( year, month, day ) ;

    int currentyear = 365 + isLeapYear( year ) ;

    if( daySeqOfYear > currentyear )
    {
        if( getDaySeqOfWeek( year + 1, daySeqOfYear - currentyear) == 0)
        {
            week = ( daySeqOfYear + getDaySeqOnJan1( year ) ) / 7 ;
        }

        else
        {
            week = ( daySeqOfYear + getDaySeqOnJan1( year ) +
                   ( 7 - getDaySeqOfWeek( year + 1, daySeqOfYear - currentyear))) / 7 ;
        }
    }

    else
    {
        if( getDaySeqOfWeek( year , daySeqOfYear ) == 0)
        {
            week = ( daySeqOfYear + getDaySeqOnJan1( year ) ) / 7 ;
        }

        else
        {
            week = ( daySeqOfYear + getDaySeqOnJan1( year ) +
                   ( 7 - getDaySeqOfWeek( year , daySeqOfYear)))/ 7 ;
        }
    }

    return week;
}

void setYearArray( int Years[], int yearnum, int year )
{
    int num1 ;

    for( num1 = 0; num1 < yearnum ; num1 ++ , year ++)
    {
        Years[ num1 ] = year;
    }
}
