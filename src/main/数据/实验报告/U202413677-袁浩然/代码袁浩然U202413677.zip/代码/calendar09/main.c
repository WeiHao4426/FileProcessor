#include <stdio.h>
#include <stdlib.h>
#include "date.h"
#include "funs.h"

const int Month_NORMAL_YEAR [12] =
{31,28,31,30,31,30,31,31,30,31,30,31};

const int Month_LEAP_YEAR [12] =
{31,29,31,30,31,30,31,31,30,31,30,31};


int main()
{
    int inputMonth, inputDay, Years[YEAR_NUM];
    printf("Finding Birthday in year (%d-%d), please input the month and day : \n", YEAR_MIN, YEAR_MAX );

    scanf("%d%d", &inputMonth, &inputDay );

    if ( inputMonth < 1 || inputMonth > 12 || inputDay < 1 || inputDay > 31)
    {
        printf("Sorry, the input month and day are invalid.\n");
        return 1;
    }

    setYearArray ( Years, YEAR_NUM, YEAR_MIN );

    int Days[YEAR_NUM][366][4] = {0};

    initialDays ( Years, Days, YEAR_NUM);

    int totalNum = 0;
    int weekendNum = 0;

   int i,j;
   for( i = 0; i < YEAR_NUM; i ++)
   {
       printf("\n%1s%s%d\n","","Birthday in Year ", Years[i] );
       for( j = 0; j < 366; j ++)
        {
            if(Days[i][j][0] == inputMonth&&Days[i][j][1] == inputDay)
            {
                totalNum ++;
                printf("#M:%10s%10s%10s%10s%10s%10s%10s\n",
                "Mon.","Tues.","Wed.","Thur.","Fri.","Sat.","Sun.");
                printoneWeek( Years[ i ], getWeekSeqOfYear( Years[ i ], inputMonth,  inputDay), inputMonth);
                if(Days[i][j][3] == 6||Days[i][j][3] == 0)
                {
                    weekendNum ++;
                }
                break;
            }
            if(j == 365)
            {
                printf(" Not found.\n");
            }
        }
    }


    printf("\nTotal %d birthday are found, %d of them are in weekends.\n", totalNum, weekendNum);
    return 0;
}




void initialDays(int Years[], int Days[][366][4], int yearNum )
{
    int year, month, day, yearLength, weekSeq, seqOfWeek;
    int i, j;

    for (i = 0; i < YEAR_NUM; i ++)
    {
        year = Years[i];
        yearLength = isLeapYear( year ) ? 366 : 365;
        for(j = 0; j < yearLength; j ++)
        {
        Days[i][j][0] = getMonth( year, j + 1);
        Days[i][j][1] = getDay( year, j + 1 );
        Days[i][j][2] = getWeekSeqOfYear( year, Days[i][j][0], Days[i][j][1] );
        Days[i][j][3] = getDaySeqOfWeek( year, j + 1 );
        }
    }
}
